/* Version number of hodie */

#define HODIE_RELEASE "1.4"
