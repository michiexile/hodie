#include "includes.h"

void
print_usage(void)
{
    printf("%s",HELP_1);
    printf("%s",HELP_2);
    printf("%s",HELP_3);
    printf("%s",HELP_4);
    printf("%s",HELP_5);
    printf("%s",HELP_7);
    printf("%s",HELP_8);
    printf("%s",HELP_9);
    printf("%s",HELP_10);
    printf("%s",HELP_11);
    printf("%s",HELP_12);
    printf("%s",HELP_13);
    printf("%s",HELP_14);
    printf("%s",HELP_15);
    printf("%s",HELP_16);
    printf("%s",HELP_17);
    printf("%s",HELP_18);
    printf("%s",HELP_19);
    printf("%s",HELP_20);
}
